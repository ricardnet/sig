-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 20, 2024 at 02:06 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sig_desaku`
--

-- --------------------------------------------------------

--
-- Table structure for table `disaster_records`
--

CREATE TABLE `disaster_records` (
  `id` int(11) NOT NULL,
  `disaster_type` enum('banjir','longsor','kebakaran','angin_kencang','kekeringan') NOT NULL,
  `location` text NOT NULL,
  `rt` varchar(3) NOT NULL,
  `rw` varchar(3) NOT NULL,
  `severity_level` enum('rendah','sedang','tinggi','kritis') NOT NULL,
  `latitude` decimal(10,8) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  `affected_families` int(11) NOT NULL,
  `affected_people` int(11) NOT NULL,
  `casualties` int(11) DEFAULT 0,
  `description` text DEFAULT NULL,
  `status` enum('aktif','selesai','pemulihan') NOT NULL,
  `reported_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `disaster_records`
--

INSERT INTO `disaster_records` (`id`, `disaster_type`, `location`, `rt`, `rw`, `severity_level`, `latitude`, `longitude`, `affected_families`, `affected_people`, `casualties`, `description`, `status`, `reported_by`, `created_at`, `updated_at`) VALUES
(1, 'kebakaran', 'demak', '', '', 'sedang', 0.00000000, 0.00000000, 0, 0, 0, 'bantuan', '', 0, '2024-12-15 03:19:48', '2024-12-15 03:19:48'),
(2, 'angin_kencang', 'demak', '', '', 'sedang', -6.92423749, 110.77885866, 0, 0, 0, 'extreme', '', 0, '2024-12-20 12:56:44', '2024-12-20 12:56:44');

-- --------------------------------------------------------

--
-- Table structure for table `disaster_reports`
--

CREATE TABLE `disaster_reports` (
  `id` int(11) NOT NULL,
  `disaster_id` int(11) NOT NULL,
  `report_type` enum('awal','perkembangan','akhir') NOT NULL,
  `description` text NOT NULL,
  `action_taken` text DEFAULT NULL,
  `resources_needed` text DEFAULT NULL,
  `reported_by` int(11) NOT NULL,
  `report_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `emergency_contacts`
--

CREATE TABLE `emergency_contacts` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `organization` varchar(100) NOT NULL,
  `contact_type` enum('polisi','pemadam','ambulans','SAR','lainnya') NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `alternative_number` varchar(15) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `evacuation_points`
--

CREATE TABLE `evacuation_points` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `capacity` int(11) NOT NULL,
  `facilities` text DEFAULT NULL,
  `latitude` decimal(10,8) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  `status` enum('siap','penuh','tidak_aktif') NOT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `contact_number` varchar(15) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `health_records`
--

CREATE TABLE `health_records` (
  `id` int(11) NOT NULL,
  `citizen_nik` varchar(16) NOT NULL,
  `citizen_name` varchar(100) NOT NULL,
  `date_of_birth` date NOT NULL,
  `gender` enum('L','P') NOT NULL,
  `address` text NOT NULL,
  `rt` varchar(3) NOT NULL,
  `rw` varchar(3) NOT NULL,
  `health_condition` varchar(50) NOT NULL,
  `health_description` text DEFAULT NULL,
  `blood_type` enum('A','B','AB','O') DEFAULT NULL,
  `disability` varchar(100) DEFAULT NULL,
  `chronic_disease` varchar(100) DEFAULT NULL,
  `insurance_number` varchar(50) DEFAULT NULL,
  `emergency_contact` varchar(15) DEFAULT NULL,
  `latitude` decimal(10,8) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  `status` varchar(100) NOT NULL,
  `recorded_by` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `health_records`
--

INSERT INTO `health_records` (`id`, `citizen_nik`, `citizen_name`, `date_of_birth`, `gender`, `address`, `rt`, `rw`, `health_condition`, `health_description`, `blood_type`, `disability`, `chronic_disease`, `insurance_number`, `emergency_contact`, `latitude`, `longitude`, `status`, `recorded_by`, `created_at`, `updated_at`) VALUES
(1, '1234567891124567', 'kaji2', '0000-00-00', 'L', '', '', '', 'sehat', 'zsss', NULL, NULL, NULL, NULL, NULL, 0.00000000, 0.00000000, 'rawat_jalan', 'ihsan', '2024-12-09 04:13:06', '2024-12-09 04:13:06'),
(3, '1234567891124567', 'RYAN', '0000-00-00', 'L', '', '', '', 'sehat', 'YES', NULL, NULL, NULL, NULL, NULL, -6.21647904, 107.14485168, 'isolasi_mandiri', 'admin', '2024-12-09 04:15:18', '2024-12-09 04:18:32'),
(4, '2223124516712343', 'AMIR', '0000-00-00', 'L', '', '', '', 'sakit berat', 'DB', NULL, NULL, NULL, NULL, NULL, -6.81435933, 110.84140778, 'rawat inap', 'admin', '2024-12-09 04:21:16', '2024-12-09 04:21:16'),
(5, '3332514763419274', 'AMIR', '0000-00-00', 'L', '', '', '', 'sehat', 'ok', NULL, NULL, NULL, NULL, NULL, -6.81108350, 110.83677292, 'rawat inap', 'admin', '2024-12-15 01:18:50', '2024-12-15 01:18:50');

-- --------------------------------------------------------

--
-- Table structure for table `medical_facilities`
--

CREATE TABLE `medical_facilities` (
  `id` int(11) NOT NULL,
  `facility_name` varchar(100) NOT NULL,
  `facility_type` enum('puskesmas','posyandu','klinik','rumah_sakit') NOT NULL,
  `address` text NOT NULL,
  `capacity` int(11) NOT NULL,
  `available_beds` int(11) NOT NULL,
  `medical_staff` int(11) NOT NULL,
  `facilities` text DEFAULT NULL,
  `latitude` decimal(10,8) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  `contact_number` varchar(15) DEFAULT NULL,
  `operating_hours` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `resource_inventory`
--

CREATE TABLE `resource_inventory` (
  `id` int(11) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `category` enum('medis','makanan','air','pakaian','tenda','lainnya') NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit` varchar(20) NOT NULL,
  `condition_status` enum('baik','rusak_ringan','rusak_berat') NOT NULL,
  `storage_location` text NOT NULL,
  `last_checked` date NOT NULL,
  `expiry_date` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `response_teams`
--

CREATE TABLE `response_teams` (
  `id` int(11) NOT NULL,
  `team_name` varchar(100) NOT NULL,
  `team_leader` int(11) NOT NULL,
  `specialization` varchar(100) NOT NULL,
  `member_count` int(11) NOT NULL,
  `equipment` text DEFAULT NULL,
  `status` enum('siap','bertugas','istirahat') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `role` enum('admin','petugas','warga') NOT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `full_name`, `role`, `phone_number`, `email`, `address`, `created_at`, `updated_at`) VALUES
(1, 'admin', '$2y$10$e.Vx1iCqjJyMEh0.JfYMpuHUY5EAwmjZi5VGGipKnNOvE6cMjJ1bG', 'admin', 'petugas', '085728435178', '123@gmail.com', 'wilalung', '2024-12-08 07:56:55', '2024-12-08 07:56:55'),
(4, 'ihsan', '$2y$10$1N/ndeYW7JblHnISMaghqO74zjEZliY4eXYUrAJX81ONgzAvEefx6', 'ihsan', '', NULL, 'kaji@gmail.com', NULL, '2024-12-09 01:24:32', '2024-12-09 01:24:32'),
(7, 'rizky', '$2y$10$5IFqihxoQFmwpxSjPX/10u1.uT2O/YnA3WgO4HbCY9npNbD1NyiWW', 'RIZKY', '', NULL, 'qwerty@gmail.com', NULL, '2024-12-09 04:24:21', '2024-12-09 04:24:21'),
(8, 'rio', '$2y$10$DeNeXaGgeAN2Focg2d8dB.mXoa0QXX0HkfKdvd6Nm7sc9GCgXwlge', 'bimo', '', NULL, 'rio123@gmail.com', NULL, '2024-12-15 02:02:08', '2024-12-15 02:02:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `disaster_records`
--
ALTER TABLE `disaster_records`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reported_by` (`reported_by`);

--
-- Indexes for table `disaster_reports`
--
ALTER TABLE `disaster_reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `disaster_id` (`disaster_id`),
  ADD KEY `reported_by` (`reported_by`);

--
-- Indexes for table `emergency_contacts`
--
ALTER TABLE `emergency_contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `evacuation_points`
--
ALTER TABLE `evacuation_points`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `health_records`
--
ALTER TABLE `health_records`
  ADD PRIMARY KEY (`id`),
  ADD KEY `recorded_by` (`recorded_by`);

--
-- Indexes for table `medical_facilities`
--
ALTER TABLE `medical_facilities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `resource_inventory`
--
ALTER TABLE `resource_inventory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `response_teams`
--
ALTER TABLE `response_teams`
  ADD PRIMARY KEY (`id`),
  ADD KEY `team_leader` (`team_leader`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `disaster_records`
--
ALTER TABLE `disaster_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `disaster_reports`
--
ALTER TABLE `disaster_reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `emergency_contacts`
--
ALTER TABLE `emergency_contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `evacuation_points`
--
ALTER TABLE `evacuation_points`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `health_records`
--
ALTER TABLE `health_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `medical_facilities`
--
ALTER TABLE `medical_facilities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `resource_inventory`
--
ALTER TABLE `resource_inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `response_teams`
--
ALTER TABLE `response_teams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
